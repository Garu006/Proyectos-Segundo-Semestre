'''Leer si un numero es par o impar'''

print("Ingrese un numero: ")
num1 = int(input())

if int(num1) % 2 == 0:
    print("El numero que ingresaste es par.")
else:
    print("El numero que ingresaste es impar.")    