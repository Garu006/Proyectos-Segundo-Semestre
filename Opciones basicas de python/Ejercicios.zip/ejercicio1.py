'''Leer si un numero es mayor o menor que 100'''

print("Ingrese un numero")
num1 = int(input())

if num1 > 100:
    print("El numero que ingresaste es mayor que 100")
else:
    print("El numero que ingresaste es menor que 100") 
